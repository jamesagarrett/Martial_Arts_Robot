from controller import Supervisor
import scenic
from scenic.simulators.webots import WebotsSimulator
from verifai.falsifier import generic_falsifier
from verifai.samplers.feature_sampler import *
from verifai.samplers.scenic_sampler import ScenicSampler
from verifai.monitor import specification_monitor
from verifai.falsifier import generic_falsifier
from dotmap import DotMap
from verifai.scenic_server import ScenicServer


path = "/Users/suryasuresh/Desktop/Martial_Arts_Robot/test/Webots/mars/project.scenic"
print(f'Loading Scenic scenario {path}')

params = {'verifaiSamplerType': 'scenic'}
params['render'] = True

sampler = ScenicSampler.fromScenario(path, **params)

falsifier_params = DotMap(
        n_iters=5,
        save_error_table=True,
        save_safe_table=True,
        max_time=None,
    )

server_options = DotMap(maxSteps=300, verbosity=0,
    scenic_path=path, scenario_params=params, num_workers=5)

class distance(specification_monitor):
    def __init__(self):
        def specification(simulation):
            positions = np.array(simulation.result.trajectory)
            distances = positions[:, [0], :] - positions[:, 1:, :]
            distances = np.linalg.norm(distances, axis=2)
            rho = np.min(distances) - 5
            return rho
        
        super().__init__(specification)


falsifier = generic_falsifier(sampler=sampler, falsifier_params=falsifier_params,
                                  sampler_type = 'scenic',
                                  server_class=ScenicServer,
                                  server_options=server_options,
                                  monitor=distance())
falsifier.run_falsifier()
    
# simulation.result.records = { ‘distance’: (3.4, 2.7, …), ‘blah: 5 }
# print(scene.objects[1].position, scene.objects[1]) 

